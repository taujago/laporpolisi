<style>
* {
font-size : 10px;
}

.garisbawah {
	border-bottom : #000 solid 2px;
}

</style>
<?php 
$setting = $this->cm->get_setting();
?>
<table width="100%" border="0" cellpadding="3">
  <tr>
    <td width="57%" align="center">KEPOLISIAN NEGARA REPUBLIK INDONESIA</td>
    <td width="16%">&nbsp;</td>
    <td width="27%">&nbsp;</td>
  </tr>
  <tr>
    <td align="center">DAERAH BANTEN</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><U>Jl. Syekh Nawawi Al Bantani No. 76 Serang 42121</U></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&quot;PROJUSTITIA&quot;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" align="center"><H2><U>REKOMENDASI PENILAIAN LAPORAN POLISI </U></H2> </td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
<br />
<table width="100%" border="0" cellpadding="0">
  <tr>
    <td width="70%">NOMOR : <?php echo $nomor; ?></td>
    <td width="30%">TANGGAL : <?php echo tgl_indo(flipdate($tanggal)); ?></td>
  </tr>
  <tr>
    <td colspan="2">Terlapor : </td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0">
  <tr>
    <td width="2%">&nbsp;</td>
    <td width="3%">1.</td>
    <td colspan="4">Termasuk dalam delik </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="19%">a. Murni </td>
    <td width="23%">b. Aduan</td>
    <td width="53%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>2. </td>
    <td colspan="3">Pernah dilapor / diadukan sebelumnya *) </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>a. Ya</td>
    <td>b. Tidak </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>3. </td>
    <td colspan="3">Ada barang bukti yang diserahkan *) </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>a. Ya (fotokopi)</td>
    <td>b. Tidak </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>4.</td>
    <td colspan="3">Kelompok Ka Siaga SPKT yang mengajukan *) </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>a. Ka Siaga SPKT-I</td>
    <td>b. Ka. Siaga SPKT-II</td>
    <td>c. Ka. Siaga SPKT-III</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>5.</td>
    <td colspan="3">Nama / Pangkat / tandatangan Perwira Ka Siaga SPKT-III</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0">
  <tr>
    <td width="68%">&nbsp;</td>
    <td width="32%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center">___________________________</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center">NRP </td>
  </tr>
</table><br />

<hr />
<p><strong><u>Penilaian Siaga Reskrimsus </u></strong></p>
<table width="100%" border="0" cellpadding="0">
  <tr>
    <td width="2%">&nbsp;</td>
    <td width="3%">1.</td>
    <td colspan="3">Apakah kasus yang dilaporkan / diadukan merupakan tindak pidana *) </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="16%">a. Ya </td>
    <td width="13%">b. Perdana </td>
    <td width="66%">c. Masih samar -samar. </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>2. </td>
    <td colspan="3">Apakah unsur unsur tidak pidana terpenuhi *)</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>a. Ya</td>
    <td>b. Perdata </td>
    <td>c. Belum Cukup &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;d. Perlu lidik </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>3. </td>
    <td colspan="3">Apakah bukti permulaan cukup terpenuhi *)</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>a. Ya </td>
    <td>b. Tidak </td>
    <td>c. Belum Cukup  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; d. Perlu lidik </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>4.</td>
    <td colspan="3">Saran - saran *) </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">a. Dilimpahkan ke kesatuan Reskrim wilayah </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">b, Ditolak.</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">c. Disidik lebih lanjut oleh direktorat </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp; &nbsp; &nbsp; &nbsp; Subdit I / Subdit II / Subdit III / Subdit IV </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>5.</td>
    <td colspan="3">Nama / Pangkat / tandatangan Perwira Siaga Ditreskrim </td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0">
  <tr>
    <td width="68%">&nbsp;</td>
    <td width="32%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center">___________________________</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center">NRP </td>
  </tr>
</table>
<p>Saran / Pendapat Bin Ops : <br />
<strong>Disposisi Kabag Binops : </strong></p>
