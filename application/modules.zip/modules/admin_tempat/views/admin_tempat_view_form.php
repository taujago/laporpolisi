<div class="modal fade" id="pengguna_modal" tabindex="-1" role="dialog" aria-labelledby="saksiModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="titleModal">Tambah Kelompok</h4>
      </div>
      <div class="modal-body">
        
<form action="" id="formulir" method="post">
            <table width="100%"  class='table table-bordered'>
              <tr>
               
              <tr><td width="30%" >Kategori Tempat </td>
              <TD><input type="text" class="form-control" name="jenis_lokasi" id="jenis_lokasi" placeholder="Kategori tempat kejahatan " /> </TD></tr>


              



                 

                
              
            </table>
            <input type="hidden" name="id_jenis_lokasi" value=""  id="id_jenis_lokasi"  />
       
            
             </form>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn btn-primary" onclick="return simpan();"  >Simpan</button>
      </div>
    </div>
  </div>
</div>
